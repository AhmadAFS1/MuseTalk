class InternalError(Exception):
    pass


class InvalidAccessError(Exception):
    pass


class InvalidStateError(Exception):
    pass


class OperationError(Exception):
    pass
